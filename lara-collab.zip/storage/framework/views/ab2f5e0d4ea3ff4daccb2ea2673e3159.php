<?php
    $name = $filter->queryName();
    $classes = 'boolean ' . $name;
?>

<?php if (isset($component)) { $__componentOriginal0db2769cdf26046821a894d37632a7f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0db2769cdf26046821a894d37632a7f7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'lacodix-filter::components.filters.layout','data' => ['filter' => $filter,'class' => $classes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lacodix-filter::filters.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['filter' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filter),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($classes)]); ?>
    <?php $__currentLoopData = $filter->options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label class="filter-input">
            <input
            class="filter-checkbox"
            name="<?php echo e($name); ?>[<?php echo e(is_numeric($key) ? $option : $key); ?>]"
            type="checkbox"
            onchange="this.form.submit()"
            value="1"
            <?php echo e(request()->get($name . '.' . $option, false) ? 'checked' : ''); ?>

        > <?php echo e($option); ?></label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0db2769cdf26046821a894d37632a7f7)): ?>
<?php $attributes = $__attributesOriginal0db2769cdf26046821a894d37632a7f7; ?>
<?php unset($__attributesOriginal0db2769cdf26046821a894d37632a7f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0db2769cdf26046821a894d37632a7f7)): ?>
<?php $component = $__componentOriginal0db2769cdf26046821a894d37632a7f7; ?>
<?php unset($__componentOriginal0db2769cdf26046821a894d37632a7f7); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\lara-collab\vendor\lacodix\laravel-model-filter\resources\views\components\filters\boolean.blade.php ENDPATH**/ ?>