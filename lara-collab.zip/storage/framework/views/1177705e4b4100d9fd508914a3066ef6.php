<?php
    $multiple = $filter->mode->needsMultipleValues();
    $varName = $filter->queryName();
    $name = $varName . ($multiple ? '[]' : '');
    $classes = 'numeric ' . $varName;
?>
<?php if (isset($component)) { $__componentOriginal0db2769cdf26046821a894d37632a7f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0db2769cdf26046821a894d37632a7f7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'lacodix-filter::components.filters.layout','data' => ['filter' => $filter,'class' => $classes]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('lacodix-filter::filters.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['filter' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filter),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($classes)]); ?>
    <?php if($multiple): ?>
        <input
            class="filter-input"
            name="<?php echo e($name); ?>"
            type="number"
            id="<?php echo e($varName); ?>_from"
            onchange="if (this.value && document.getElementById('<?php echo e($name); ?>_to').value || ! this.value && ! document.getElementById('<?php echo e($name); ?>_to').value) this.form.submit();"
            value="<?php echo e(request()->get($varName, [])[0] ?? ''); ?>"
        >
        <input
            class="filter-input"
            name="<?php echo e($name); ?>"
            type="number"
            id="<?php echo e($varName); ?>_to"
            onchange="if (this.value && document.getElementById('<?php echo e($name); ?>_from').value || ! this.value && ! document.getElementById('<?php echo e($name); ?>_from').value) this.form.submit();"
            value="<?php echo e(request()->get($varName, [])[1] ?? ''); ?>"
        >
    <?php else: ?>
        <input
            class="filter-input"
            name="<?php echo e($name); ?>"
            type="number"
            onchange="this.form.submit()"
            value="<?php echo e(request()->get($varName, '')); ?>"
        >
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0db2769cdf26046821a894d37632a7f7)): ?>
<?php $attributes = $__attributesOriginal0db2769cdf26046821a894d37632a7f7; ?>
<?php unset($__attributesOriginal0db2769cdf26046821a894d37632a7f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0db2769cdf26046821a894d37632a7f7)): ?>
<?php $component = $__componentOriginal0db2769cdf26046821a894d37632a7f7; ?>
<?php unset($__componentOriginal0db2769cdf26046821a894d37632a7f7); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\lara-collab\vendor\lacodix\laravel-model-filter\resources\views\components\filters\numeric.blade.php ENDPATH**/ ?>